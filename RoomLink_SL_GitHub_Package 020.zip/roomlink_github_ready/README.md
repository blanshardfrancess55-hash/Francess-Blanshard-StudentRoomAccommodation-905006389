# RoomLink SL — Student Accommodation

![RoomLink SL homepage preview](screenshots/homepage-preview.png)

## Project overview

RoomLink SL is a student accommodation website concept designed to help students explore sample room and housing options in Sierra Leone. The project is intended as an academic demonstration. Listings and contact information are sample content and should be verified before real-world use.

## Features

- Responsive student accommodation website interface.
- Accommodation discovery and listing content.
- Contact page with map section.
- Sample room photographs stored in the `images/` folder.
- Homepage preview image stored in `screenshots/`.

## Project files

```text
RoomLink_SL/
├── index.html
├── images/
│   ├── room-1.jpg
│   ├── room-2.jpg
│   ├── room-3.jpg
│   ├── room-4.jpg
│   ├── room-5.jpg
│   └── room-6.jpg
├── screenshots/
│   └── homepage-preview.png
└── README.md
```

## How to run

1. Download or clone this repository.
2. Open `index.html` in a modern web browser.
3. Keep an internet connection available for external libraries, fonts, or map content used by the page.

## GitHub Pages

To publish the website, open the repository's **Settings → Pages**, select the `main` branch and `/ (root)` folder, and save. GitHub will display a website URL after Pages finishes publishing.

## Notes

This is a student project/demo. Sample listings, prices, and contact details are not verified real accommodation offers. The homepage preview is included in this README using a relative image path so it appears on GitHub.
